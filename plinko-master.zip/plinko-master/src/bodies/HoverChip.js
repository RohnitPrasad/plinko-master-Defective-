// revisit to send HoverChips in snapshots

//
// import GameObject from './GameObject';
//
// export default class HoverChip extends GameObject {
//   constructor({ x, y, ownerId }) {
//     super({ x, y, ownerId });
//     this.type = 'hover_chip';
//   }
// }
