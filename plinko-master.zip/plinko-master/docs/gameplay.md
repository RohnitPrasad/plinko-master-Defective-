# MULTIPLAYER

Up to X users may join a game. Each user has their own unique color.

Users may drop an unlimited number of chips at will.

When chips collide with pegs, the pegs change color to match the user's color.

Chips collect in the buckets at the bottom of the frame until X seconds have passed, when they begin to shrink and disappear.

The goal is to change the color of a target percentage of pegs.
  -target options:
    -*percentage starts at 100% and drops over time*
    -50%
    -changing percentage based on number of players

When a user wins, any user may start a new game.
